import cv2 as cv
import numpy as np

# Function to get image from path


def get_image(path):
    img = cv.imread(path)
    return img


# Function to get points and store it into Array Circles
circles = np.zeros((4, 2), np.int)


def img_crop(img, x1, x2, y1, y2):
    """Crop the image with opencv"""
    circles[0] = x1, y1
    circles[1] = x2, y1
    circles[2] = x1, y2
    circles[3] = x2, y2
    width, height = 600, 500
    # Points that we click on image and store on Circles
    pts1 = np.float32([circles[0], circles[1], circles[2], circles[3]])
    # Standard Points
    pts2 = np.float32([[0, 0], [width, 0], [0, height], [width, height]])
    # Transformation Matrix
    matrix = cv.getPerspectiveTransform(pts1, pts2)
    imgOutPut = cv.warpPerspective(img, matrix, (width, height))
    return imgOutPut


# Esmael is coding this part
# load the images and we dont need to switch between them
img1 = get_image('Resources\Resources\img1.png')
img2 = get_image('Resources\Resources\img2.png')
img3 = get_image('Resources\Resources\img3.png')
img4 = get_image('Resources\Resources\img4.png')
img5 = get_image('Resources\Resources\img5.png')
img6 = get_image('Resources\Resources\img6.png')
img7 = get_image('Resources\Resources\img7.png')
img8 = get_image('Resources\Resources\img8.png')

#  resize the images
img1 = cv.resize(img1, (500, 450))
img2 = cv.resize(img2, (500, 450))
img3 = cv.resize(img3, (500, 450))
img4 = cv.resize(img4, (500, 450))
img5 = cv.resize(img5, (500, 500))
img6 = cv.resize(img6, (500, 503))
img7 = cv.resize(img7, (500, 510))
img8 = cv.resize(img8, (500, 500))

# Mohamed is coding this part
# crop the images with opencv
# (the img, start row, end row, start column, end column)
img1 = img_crop(img1, 0, 480, 50, 420)
img2 = img_crop(img2, 40, 470, 0, 425)
img3 = img_crop(img3, 60, 450, 6, 410)
img4 = img_crop(img4, 60, 500, 6, 433)
img5 = img_crop(img5, 10, 475, 90, 490)
img6 = img_crop(img6, 50, 440, 95, 495)
img7 = img_crop(img7, 25, 380, 105, 510)
img8 = img_crop(img8, 15, 455, 125, 490)

# show the images in a grid
# concatenate the images in pairs horizontally
img1 = cv.hconcat([img1, img2])
img2 = cv.hconcat([img3, img4])
img3 = cv.hconcat([img5, img6])
img4 = cv.hconcat([img7, img8])
# concatenate the 4 images horizontally into one image
img1 = cv.hconcat([img1, img2])
img2 = cv.hconcat([img3, img4])
# concatenate the 2 images vertically into one image (img) and resize it
img = cv.vconcat([img1, img2])
img = cv.resize(img, (800, 500))

# show the image
cv.imshow('Image', img)
cv.waitKey(0)
cv.destroyAllWindows()
