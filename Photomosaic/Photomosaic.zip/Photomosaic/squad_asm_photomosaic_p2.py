import cv2
import numpy as np
import time

# Esmael is coding this part
# Get video from path
vidcap = cv2.VideoCapture('Resources\Resources\Forwards-Backwards.mp4')

# Function to get frame from video and save it as image


def getFrame(sec):
    vidcap.set(cv2.CAP_PROP_POS_MSEC, sec*1000)
    hasFrames, image = vidcap.read()
    if hasFrames:
        if count < 10:
            print("we dont need to save the image")
        # save frame as JPG file
        else:
            cv2.imwrite("image"+str(count)+".jpg", image)
    return hasFrames

# Function to get image from path


def get_image(path):
    img = cv2.imread(path)
    return img


# Moahmed is coding this part
# Function to get points and store it into Array Circles
circles = np.zeros((4, 2), np.int)


def img_crop(img, x1, x2, y1, y2):
    """Crop the image with opencv"""
    circles[0] = x1, y1
    circles[1] = x2, y1
    circles[2] = x1, y2
    circles[3] = x2, y2
    width, height = 600, 500
    # Points that we click on image and store on Circles
    pts1 = np.float32([circles[0], circles[1], circles[2], circles[3]])
    # Standard Points
    pts2 = np.float32([[0, 0], [width, 0], [0, height], [width, height]])
    # Transformation Matrix
    matrix = cv2.getPerspectiveTransform(pts1, pts2)
    imgOutPut = cv2.warpPerspective(img, matrix, (width, height))
    return imgOutPut


# Get and save the images from video every 0.5 seconds
sec = 0
frameRate = 0.5  # //it will capture image in each 0.5 second
count = 1
success = getFrame(sec)
while success:
    count = count + 1
    sec = sec + frameRate
    sec = round(sec, 2)
    success = getFrame(sec)

# wait 2 seconds
time.sleep(2)


# load the images and we dont need to switch between them
img1 = get_image('image10.jpg')
img2 = get_image('image10.jpg')
img3 = get_image('image10.jpg')
img4 = get_image('image11.jpg')
img5 = get_image('image16.jpg')
img6 = get_image('image16.jpg')
img7 = get_image('image18.jpg')
img8 = get_image('image18.jpg')

# switch between the images
img1, img4 = img4, img1


#  resize the images
img1 = cv2.resize(img1, (500, 550))
img2 = cv2.resize(img2, (500, 550))
img3 = cv2.resize(img3, (500, 550))
img4 = cv2.resize(img4, (500, 550))
img5 = cv2.resize(img5, (500, 550))
img6 = cv2.resize(img6, (500, 600))
img7 = cv2.resize(img7, (500, 550))
img8 = cv2.resize(img8, (500, 550))


# crop the images with opencv
# (the img, start row, end row, start column, end column)
img1 = img_crop(img1, 70, 450, 25, 160)
img2 = img_crop(img2, 70, 450, 25, 140)
img3 = img_crop(img3, 70, 450, 141, 290)
img4 = img_crop(img4, 70, 450, 300, 425)
img5 = img_crop(img5, 70, 410, 276, 411)
img6 = img_crop(img6, 70, 410, 450, 598)
img7 = img_crop(img7, 60, 410, 216, 367)
img8 = img_crop(img8, 70, 410, 370, 502)

# show the images in a grid
# concatenate the images in pairs horizontally
img1 = cv2.vconcat([img1, img2])
img2 = cv2.vconcat([img3, img4])
img3 = cv2.vconcat([img5, img6])
img4 = cv2.vconcat([img7, img8])
# concatenate the 4 images horizontally into one image
img1 = cv2.vconcat([img1, img2])
img2 = cv2.vconcat([img3, img4])
# concatenate the 2 images vertically into one image (img) and resize it
img = cv2.hconcat([img1, img2])
img = cv2.resize(img, (500, 500))

cv2.imshow('Image', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
