from PyQt5.QtWidgets import QMainWindow, QApplication, QLabel, QPushButton, QComboBox
from PyQt5 import uic
from PyQt5.QtMultimedia import *
from PyQt5.QtMultimediaWidgets import *
from PyQt5.QtCore import QTimer
from PyQt5.Qt import Qt
import sys


class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("GUI ROV DESGIN\Vortexgui.ui", self)
        self.setWindowTitle("Main Window")

        """Camera"""
        # Declare the camera labels
        self.CameraLabel1 = self.findChild(QLabel, "Camera1_label")
        self.CameraLabel2 = self.findChild(QLabel, "Camera2_label")
        # open the camera and display the video
        self.camera = QCamera()
        self.camera.setCaptureMode(QCamera.CaptureStillImage)
        self.camera.start()
        self.viewfinder = QCameraViewfinder()
        self.camera.setViewfinder(self.viewfinder)

        """Vechicals Indirectors"""
        # Declare the vichle icons
        self.frwd_arrow = self.findChild(QLabel, "frwd_arrow")
        self.left_arrow = self.findChild(QLabel, "left_arrow")
        self.bckwrd_arrow = self.findChild(QLabel, "bckwrd_arrow")
        self.right_arrow = self.findChild(QLabel, "right_arrow")
        self.roatete1_arrow = self.findChild(QLabel, "roatete1_arrow")
        self.roatete2_arrow = self.findChild(QLabel, "roatete2_arrow")
        self.Up_arrow = self.findChild(QLabel, "Up_arrow")
        self.Down_arrow = self.findChild(QLabel, "Down_arrow")
        self.grapper_close_hro = self.findChild(QLabel, "grapper_close_hro")
        self.grapper_close = self.findChild(QLabel, "grapper_close")
        self.grapper_Open = self.findChild(QLabel, "grapper_Open")
        self.grapper_Open_hro = self.findChild(QLabel, "grapper_Open_hro")
        self.frwd_arrow_Green = self.findChild(QLabel, "frwd_arrow_Green")
        self.right_arrow_Green = self.findChild(QLabel, "right_arrow_Green")
        self.bckwrd_arrow_Green = self.findChild(QLabel, "bckwrd_arrow_Green")
        self.left_arrow_Green = self.findChild(QLabel, "left_arrow_Green")
        self.roatete2_arrow_Green = self.findChild(
            QLabel, "roatete2_arrow_Green")
        self.roatete1_arrow_Green = self.findChild(
            QLabel, "roatete1_arrow_Green")
        self.Up_arrow_Green = self.findChild(QLabel, "Up_arrow_Green")
        self.Down_arrow_Green = self.findChild(QLabel, "Down_arrow_Green")
        # Set The Defualt Value as Hide for the unselected icons
        self.frwd_arrow_Green.hide()
        self.right_arrow_Green.hide()
        self.bckwrd_arrow_Green.hide()
        self.left_arrow_Green.hide()
        self.roatete2_arrow_Green.hide()
        self.roatete1_arrow_Green.hide()
        self.Up_arrow_Green.hide()
        self.Down_arrow_Green.hide()
        self.grapper_Open.hide()
        self.grapper_Open_hro.hide()

        """Timeup Counter"""
        # Set variables for the initial state of the timer
        self.counter = 0
        self.minute = '00'
        self.second = '00'
        self.count = '00'
        self.startWatch = False
        self.hidden = False
        # Declare the timer and connect it
        self.Timer = self.findChild(QLabel, "Timer")
        self.Start_Button = self.findChild(QPushButton, "Start_Button")
        self.Start_Button.pressed.connect(self.Start)
        self.Reset_button = self.findChild(QPushButton, "Reset_button")
        self.Reset_button.pressed.connect(self.Reset)
        self.Stop_button = self.findChild(QPushButton, "Stop_button")
        # Create timer object
        timer = QTimer(self)
        # connect timer to function
        timer.timeout.connect(self.showCounter)
        # Call start() method to modify the timer value
        timer.start(100)
        # Move the position of the window
        self.move(900, 400)

        """ComboBox Script"""
        # Declear Button and ComboBox for Script Section
        self.Run_button = self.findChild(QPushButton, "Run_button")
        self.ComboBox_Script = self.findChild(QComboBox, "ComboBox_Script")
        # Add the items to the combobox
        self.ComboBox_Script.addItem("Code1")
        self.ComboBox_Script.addItem("Code2")
        self.ComboBox_Script.addItem("Code3")
        # Connect the combobox to the function when the user select an item and press the run button
        self.Run_button.clicked.connect(lambda: self.Code_Script())

        """Current Mode"""
        # Declear Buttons and Label on Current Mode
        self.ModeLabel = self.findChild(QLabel, "Mode_label")
        self.button_Autonmous = self.findChild(QPushButton, "Autonmous_button")
        self.DepHold_button = self.findChild(QPushButton, "DepHold_button")
        self.Stabilize_button = self.findChild(QPushButton, "Stabilize_button")
        self.Manu_button = self.findChild(QPushButton, "Manu_button")
        # Connects on Current Mode Section
        self.button_Autonmous.clicked.connect(
            lambda: self.press_it("Current Mode: Autonmous"))
        self.DepHold_button.clicked.connect(
            lambda: self.press_it("Current Mode: Depth Hold"))
        self.Stabilize_button.clicked.connect(
            lambda: self.press_it("Current Mode: Stabilize"))
        self.Manu_button.clicked.connect(
            lambda: self.press_it("Current Mode: Manual"))

        # Functions

    def Code_Script(self):
        """ComboBox Script to switch between code 1,2"""
        if self.ComboBox_Script.currentText() == "Code1":
            # set the label 1 as the parent of the camera
            self.viewfinder.setParent(self.CameraLabel1)
            # set the size of the label
            self.viewfinder.setGeometry(0, 0, 400, 480)
            self.viewfinder.show()
        elif self.ComboBox_Script.currentText() == "Code2":
            # set the label 2 as the parent of the camera
            self.viewfinder.setParent(self.CameraLabel2)
            # set the size of the label
            self.viewfinder.setGeometry(0, 0, 400, 480)
            self.viewfinder.show()
        else:
            # stop the camera
            self.camera.stop()
            self.viewfinder.hide()
# --------------------------------------------

    def keyPressEvent(self, event):
        """Vechicals Indirectors if code 3 is selected"""
        if self.ComboBox_Script.currentText() == "Code3":
            # Take Input from Keyboard to control the ROV
            if event.key() == Qt.Key_W and self.hidden:
                self.frwd_arrow_Green.show()
                self.frwd_arrow.hide()
                self.hidden = False
            elif event.key() == Qt.Key_S and self.hidden:
                self.bckwrd_arrow_Green.show()
                self.bckwrd_arrow.hide()
                self.hidden = False
            elif event.key() == Qt.Key_A and self.hidden:
                self.left_arrow_Green.show()
                self.left_arrow.hide()
                self.hidden = False
            elif event.key() == Qt.Key_D and self.hidden:
                self.right_arrow_Green.show()
                self.right_arrow.hide()
                self.hidden = False
            elif event.key() == Qt.Key_R and self.hidden:
                self.roatete1_arrow.hide()
                self.roatete1_arrow_Green.show()
                self.hidden = False
            elif event.key() == Qt.Key_E and self.hidden:
                self.roatete2_arrow.hide()
                self.roatete2_arrow_Green.show()
                self.hidden = False
            elif event.key() == Qt.Key_8 and self.hidden:
                self.Up_arrow.hide()
                self.Up_arrow_Green.show()
                self.hidden = False
            elif event.key() == Qt.Key_2 and self.hidden:
                self.Down_arrow.hide()
                self.Down_arrow_Green.show()
                self.hidden = False
            elif event.key() == Qt.Key_O and self.hidden:
                self.grapper_close.hide()
                self.grapper_Open.show()
                self.hidden = False
            elif event.key() == Qt.Key_H and self.hidden:
                self.grapper_close_hro.hide()
                self.grapper_Open_hro.show()
                self.hidden = False
            else:
                self.right_arrow.show()
                self.right_arrow_Green.hide()
                self.left_arrow.show()
                self.left_arrow_Green.hide()
                self.bckwrd_arrow.show()
                self.bckwrd_arrow_Green.hide()
                self.frwd_arrow.show()
                self.frwd_arrow_Green.hide()
                self.roatete2_arrow.show()
                self.roatete2_arrow_Green.hide()
                self.roatete1_arrow.show()
                self.roatete1_arrow_Green.hide()
                self.roatete2_arrow.show()
                self.roatete2_arrow_Green.hide()
                self.Up_arrow.show()
                self.Up_arrow_Green.hide()
                self.Down_arrow.show()
                self.Down_arrow_Green.hide()
                self.grapper_close.show()
                self.grapper_Open.hide()
                self.grapper_close_hro.show()
                self.grapper_Open_hro.hide()
                self.hidden = True
# --------------------------------------------

    def press_it(self, pressed):
        """Mode Label changing"""
        self.ModeLabel.setText(pressed)
# --------------------------------------------

    def showCounter(self):
        """Counter for the timer"""
        # Check the value of startWatch  variable to start or stop the Stop Watch
        if self.startWatch:
            # Increment counter by 1
            self.counter += 1
            # Count and set the time counter value
            cnt = int((self.counter/10 - int(self.counter/10))*10)
            self.count = '0' + str(cnt)
            # Set the second value
            if int(self.counter/10) < 10:
                self.second = '0' + str(int(self.counter / 10))
            else:
                self.second = str(int(self.counter / 10))
                # Set the minute value
                if self.counter / 10 == 60.0:
                    self.second == '00'
                    self.counter = 0
                    min = int(self.minute) + 1
                    if min < 10:
                        self.minute = '0' + str(min)
                    else:
                        self.minute = str(min)
        # Merge the mintue, second and count values
        text = self.minute + ':' + self.second + ':' + self.count
        # Display the stop watch values in the label
        self.Timer.setText(text)
# --------------------------------------------

    def Start(self):
        """Start the timer"""
        # Set the caption of the start button based on previous caption
        if self.Start_Button.text() == 'Stop':
            self.Start_Button.setText('Resume')
            self.startWatch = False  # Stop the timer
        else:
            # making startWatch to true
            self.startWatch = True  # Start the timer
            self.Stop_button.hide()
            self.Start_Button.setText('Stop')
# --------------------------------------------

    def Reset(self):
        """Reset the timer"""
        self.startWatch = False  # Stop the timer
        # Reset all counter variables
        self.counter = 0
        self.minute = '00'
        self.second = '00'
        self.count = '00'
        # Set the initial values for the stop watch
        self.Timer.setText(str(self.counter))
        self.Start_Button.setText('Start')
        self.Stop_button.show()
# --------------------------------------------


# Run the application
app = QApplication(sys.argv)
UIwindow = UI()
UIwindow.show()
app.exec_()
